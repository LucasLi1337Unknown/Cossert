## What changed?

## Why?

- [ ] I did not label invented syntax as official.
- [ ] I updated docs/tests/examples where relevant.
