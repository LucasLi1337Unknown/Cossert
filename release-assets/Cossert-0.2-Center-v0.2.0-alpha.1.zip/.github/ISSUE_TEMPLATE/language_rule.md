---
name: Cossert language rule
about: Document an official Cossert rule
title: "[RULE] "
labels: language-design
---

## Rule

## Official decision

## Syntax

## Examples

## Tests
