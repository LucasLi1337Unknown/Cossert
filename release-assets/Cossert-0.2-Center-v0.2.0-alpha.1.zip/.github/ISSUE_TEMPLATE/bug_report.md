---
name: Bug report
about: Report a Center bug
title: "[BUG] "
labels: bug
---

## What happened?

## Expected behavior

## Reproduction
